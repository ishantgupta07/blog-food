import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {RecipeService} from '../recipes/recipe.service';
import {forEach} from '@angular/router/src/utils/collection';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html'
})
export class HeaderComponent {

  constructor(private router: Router) { }




  logout() {
    this.router.navigate(['']);
  }
}
