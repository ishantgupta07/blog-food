import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {RecipeService} from '../recipes/recipe.service';
import {forEach} from '@angular/router/src/utils/collection';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
   // st: number = 0;
  ob: any= {};

     model: {};
  user: Object[]= [
    {

      userName: 'ishant',
      password: 'ishant'
    },
    {

      userName: 'gupta',
      password: 'gupta'
    },
    {

      userName: 'abc',
      password: 'abc'
    },
    {

      userName: 'def',
      password: 'def'
    },
    {

      userName: 'xyz',
      password: 'xyz'



}];



  constructor(private router: Router) { }

  ngOnInit() {
  }
  loginpg(e) {
    e.preventDefault();
    // var username = e.target.elements[0].value;
    // var password =  e.target.elements[1].value;
    console.log(e.target.elements[0].value, e.target.elements[1].value);
    if ( e.target.elements[0].value === 'ishant' && e.target.elements[1].value === 'ishant') {
      console.log(e.target.elements[0].value, e.target.elements[1].value);
      console.log(e.target.elements[0].value, e.target.elements[1].value);
      this.router.navigate(['recipes']);
    } else if ( e.target.elements[0].value === 'abc' && e.target.elements[1].value === 'abc') {
      this.router.navigate(['recipes']);
    } else if ( e.target.elements[0].value === 'xyz' && e.target.elements[1].value === 'xyz') {
      this.router.navigate(['recipes']);
    } else if ( e.target.elements[0].value === 'gupta' && e.target.elements[1].value === 'gupta') {
      this.router.navigate(['recipes']);
    }
    return false;

  }


}




